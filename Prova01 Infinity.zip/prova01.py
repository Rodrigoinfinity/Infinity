print ("Cálculo da área do retangulo")

base = float(input("Escreva a base do retangulo: "))

altura = float(input("Escreva a altura do retangulo: "))

area = base * altura

print ("A area do retangulo é de: ", area) 